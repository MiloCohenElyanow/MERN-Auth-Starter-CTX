



const Wrapper = ({children}) => {

  return (
    <div style={{ height: "100vh", backgroundColor: "#111"}}>
      { children }
    </div>
  )
}

export default Wrapper